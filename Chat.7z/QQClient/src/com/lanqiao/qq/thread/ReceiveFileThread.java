package com.lanqiao.qq.thread;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import com.lanqiao.qq.entity.SendFileMsg;
import com.lanqiao.qq.entity.SendFileRS;
import com.lanqiao.qq.ui.ProgressJFrame;
import com.lanqiao.qq.util.DialogUtil;
import com.lanqiao.qq.util.ObjectUtil;

public class ReceiveFileThread extends Thread {
	
	private SendFileMsg msg;
	private Socket s;
	
	public ReceiveFileThread(SendFileMsg msg,Socket s) {
		this.msg = msg;
		this.s=s;
	}

	@Override
	public void run() {
		File f=DialogUtil.saveFile(msg.getFilename());
		SendFileRS rs=new SendFileRS();
		rs.setFrom(msg.getTo());
		rs.setTo(msg.getFrom());
		rs.setFilepath(msg.getFilepath());//�����ļ�·��
		rs.setAgreed(true);
		try {
			ServerSocket ss=new ServerSocket(0);//
			ss.setSoTimeout(1000*60*3);
			rs.setPort(ss.getLocalPort());//����ǽ������
			rs.setIp(InetAddress.getLocalHost().getHostAddress().toString());
			System.out.println(ss.getLocalPort()+"====="+InetAddress.getLocalHost().getHostAddress().toString());
			ObjectUtil.writeObject(s, rs);
			Socket s=ss.accept();
			System.out.println("�ļ��������ӳɹ�������");
			InputStream is=s.getInputStream();
			FileOutputStream fos=new FileOutputStream(f);
			byte bs[]=new byte[1024*5];
			int len=0;
			ProgressJFrame pj=new ProgressJFrame();
			pj.setFilesize(msg.getFilesize());
			pj.setLable("�ļ������С���");
			pj.setLocationRelativeTo(null);
			pj.setVisible(true);
			while((len=is.read(bs))!=-1)
			{
				fos.write(bs,0,len);
				pj.setWritesize(len);
			}
			DialogUtil.showInfo("�ļ�������ϣ���");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
