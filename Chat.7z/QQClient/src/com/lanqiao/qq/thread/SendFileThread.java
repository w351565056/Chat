package com.lanqiao.qq.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import com.lanqiao.qq.entity.SendFileRS;
import com.lanqiao.qq.ui.ProgressJFrame;
import com.lanqiao.qq.util.DialogUtil;


public class SendFileThread extends Thread {

	private SendFileRS rs;
	
	public SendFileThread(SendFileRS rs) {
		super();
		this.rs = rs;
	}

	@Override
	public void run() {
		try {
			Socket  s=new Socket(rs.getIp(), rs.getPort());
			//FILE-->Socket-->
			File file=new  File(rs.getFilepath());
			FileInputStream fis=new FileInputStream(file);
			OutputStream os=s.getOutputStream();
			byte bs[]=new byte[1024*5];
			int len=0;
			//����UI
			ProgressJFrame pj=new ProgressJFrame();
			pj.setFilesize(file.length());
			pj.setLable("�ļ����ڷ����С���");
			pj.setLocationRelativeTo(null);
			pj.setVisible(true);
			while((len=fis.read(bs))!=-1)
			{
				os.write(bs,0,len);
				pj.setWritesize(len);
			}
			DialogUtil.showInfo("�ļ�������ϣ�����");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
