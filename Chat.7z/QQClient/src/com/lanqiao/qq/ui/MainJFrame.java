package com.lanqiao.qq.ui;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.lanqiao.qq.thread.ServerThread;
import com.lanqiao.qq.entity.SendMsg;
import com.lanqiao.qq.entity.User;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class MainJFrame extends javax.swing.JFrame {
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JScrollPane jScrollPane1;
	private JPanel jPanel1;
	//======================
	private User u;//��ǰ��¼�û�
	private Socket s;//���ӵ���������Socket
	//String -->account ����
	private Map<String,ChatJFrame> chats=new HashMap<String, ChatJFrame>();

	public MainJFrame(User u,Socket s) {
		super();
		this.u=u;
		this.s=s;
		initGUI();
		setTitle(u.getAccount());//���ñ���Ϊ�û��˺�
		initFriends();
		new ServerThread(s,u,this).start();//�����̼߳������������͵���Ϣ
		this.addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e){ 
            	try {
					s.close();
					System.exit(0); 
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                 
            }  
        });
	}
	
	/**
	 * �ú���ͷ������
	 * @param f
	 */
	public void tip(SendMsg msg)
	{
		//��ʾ��Ϣ�����촰��
		ChatJFrame  cj=chats.get(msg.getFrom().getAccount());
		if(cj==null)
		{
			cj=new ChatJFrame(msg.getFrom(), u, s);
			cj.setLocationRelativeTo(null);
			chats.put(msg.getFrom().getAccount(), cj);
		}
		cj.appendMsg(msg);//����������Ϣ
		if(!cj.isVisible())
		{//������ڲ��ɼ���������ͷ�񣡣���
			Component[] imgs=jPanel1.getComponents();
			for(Component c:imgs)
			{
				JLabel label=(JLabel) c;
				if(label.getToolTipText().equals(msg.getFrom().getAccount()))
				{//�ҵ���Ӧ��ͷ��
					label.setIcon(new ImageIcon(getClass()
							.getClassLoader()
							.getResource("img/icon/"+msg.getFrom().getImg()+".gif")));
					break;
				}
			}
		}
	}
	
	/**
	 * ��ʼ��ĳ�����ѵ�ͷ��
	 * @param f
	 * @return
	 */
	private JLabel  initImg(final User f)
	{
		final JLabel fimg=new JLabel();
		fimg.setIcon(new ImageIcon(getClass()
						.getClassLoader()
						.getResource("img/icon/"+f.getImg()+".png")));
		fimg.setToolTipText(f.getAccount());
		fimg.setText(f.getNickname());
		//���ϵ���¼�
		fimg.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				if(e.getClickCount()==2)
				{//�ж��Ƿ�˫����꣡����
					fimg.setIcon(new ImageIcon(getClass()
							.getClassLoader()
							.getResource("img/icon/"+f.getImg()+".png")));
					ChatJFrame cj=chats.get(f.getAccount());
					if(cj==null)
					{//��һ����ʾ
						cj=new ChatJFrame(f,u,s);
						cj.setLocationRelativeTo(null);
						cj.setVisible(true);
						//���½����Ĵ��ڷ��õ�map��
						chats.put(f.getAccount(), cj);
					}else{//�Ѿ����������
						cj.setVisible(true);//�ô�����ʾ
					}
				}
			}
		});
		return fimg;
	}
	
	/**
	 * �����º���ͷ��
	 * @param f
	 */
	public void addFriend(User f)
	{
		jPanel1.add(initImg(f));
		this.getContentPane().validate();//���¸��½���
	}
	
	/**
	 * ��ʼ������ͷ��
	 */
	private void initFriends()
	{
		List<User> ulist=u.getFriends();
		for(User f:ulist)
		{
			jPanel1.add(initImg(f));
		}
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1);
				jLabel1.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/main/1.PNG")));
				jLabel1.setBounds(0, 0, 225, 56);
			}
			{
				jLabel2 = new JLabel();
				getContentPane().add(jLabel2);
				jLabel2.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/main/2.png")));
				jLabel2.setBounds(0, 56, 35, 423);
			}
			{
				jLabel3 = new JLabel();
				getContentPane().add(jLabel3);
				jLabel3.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/main/3.png")));
				jLabel3.setBounds(-5, 479, 225, 56);
				jLabel3.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						find(evt);
					}
				});
			}
			{
				jScrollPane1 = new JScrollPane();
				getContentPane().add(jScrollPane1);
				jScrollPane1.setBounds(34, 59, 178, 421);
				{
					jPanel1 = new JPanel();
					GridLayout jPanel1Layout = new GridLayout(50, 1);
					jPanel1Layout.setHgap(5);
					jPanel1Layout.setVgap(5);
					jPanel1Layout.setColumns(1);
					jPanel1Layout.setRows(50);
					jPanel1.setLayout(jPanel1Layout);
					jScrollPane1.setViewportView(jPanel1);
				}
			}
			pack();
			this.setSize(228, 573);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void find(MouseEvent evt) {
		FindJFrame fj=new FindJFrame(s,u);
		fj.setLocationRelativeTo(null);
		fj.setVisible(true);
		
	}

}
