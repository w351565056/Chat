package com.lanqiao.qq.ui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.net.Socket;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import com.lanqiao.qq.biz.SysBiz;
import com.lanqiao.qq.entity.RegeditRS;
import com.lanqiao.qq.entity.User;
import com.lanqiao.qq.util.DialogUtil;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class RegeditJFrame extends javax.swing.JFrame {
	private JLabel jLabel1;
	private JTextField jTextField1;
	private JLabel jLabel2;
	private JPasswordField jPasswordField1;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JButton jButton1;
	private JButton jButton2;
	private JLabel jLabel6;
	private JComboBox jComboBox1;
	private JTextField jTextField3;
	private JTextField jTextField2;
	private JLabel jLabel3;
	//==========================
	private LoginJFrame loginJFrame;
	private SysBiz  sBiz;

	
	public RegeditJFrame(LoginJFrame loginJFrame,Socket s) {
		super();
		this.loginJFrame=loginJFrame;
		sBiz=new SysBiz(s);
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			getContentPane().setLayout(null);
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1);
				jLabel1.setText("\u6635\u79f0\uff1a");
				jLabel1.setBounds(23, 28, 43, 25);
			}
			{
				jTextField1 = new JTextField();
				getContentPane().add(jTextField1);
				jTextField1.setBounds(71, 29, 208, 24);
			}
			{
				jLabel2 = new JLabel();
				getContentPane().add(jLabel2);
				jLabel2.setText("\u5bc6\u7801\uff1a");
				jLabel2.setBounds(23, 78, 36, 17);
			}
			{
				jPasswordField1 = new JPasswordField();
				getContentPane().add(jPasswordField1);
				jPasswordField1.setBounds(71, 75, 208, 24);
			}
			{
				jLabel3 = new JLabel();
				getContentPane().add(jLabel3);
				jLabel3.setText("\u5e74\u9f84\uff1a");
				jLabel3.setBounds(23, 126, 36, 17);
			}
			{
				jTextField2 = new JTextField();
				getContentPane().add(jTextField2);
				jTextField2.setBounds(71, 126, 208, 24);
			}
			{
				jLabel4 = new JLabel();
				getContentPane().add(jLabel4);
				jLabel4.setText("\u90ae\u7bb1\uff1a");
				jLabel4.setBounds(23, 172, 36, 17);
			}
			{
				jTextField3 = new JTextField();
				getContentPane().add(jTextField3);
				jTextField3.setBounds(71, 169, 208, 24);
			}
			{
				jLabel5 = new JLabel();
				getContentPane().add(jLabel5);
				jLabel5.setText("\u5934\u50cf\uff1a");
				jLabel5.setBounds(323, 29, 41, 24);
			}
			{
				ComboBoxModel jComboBox1Model = 
					new DefaultComboBoxModel(
							new String[] { "Ц��", "����","��ī","����" });
				jComboBox1 = new JComboBox();
				getContentPane().add(jComboBox1);
				jComboBox1.setModel(jComboBox1Model);
				jComboBox1.setBounds(369, 29, 110, 24);
				jComboBox1.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent evt) {
						changImg(evt);
					}
				});
			}
			{
				jLabel6 = new JLabel();
				getContentPane().add(jLabel6);
				jLabel6.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/icon/1.png")));
				jLabel6.setBounds(369, 76, 50, 50);
			}
			{
				jButton1 = new JButton();
				getContentPane().add(jButton1);
				jButton1.setText("\u6ce8\u518c");
				jButton1.setBounds(322, 156, 62, 33);
				jButton1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						regedit(evt);
					}
				});
			}
			{
				jButton2 = new JButton();
				getContentPane().add(jButton2);
				jButton2.setText("\u5173\u95ed");
				jButton2.setBounds(406, 156, 61, 33);
				jButton2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						close(evt);
					}
				});
			}
			pack();
			this.setSize(521, 264);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void changImg(ItemEvent evt) {
		int index=jComboBox1.getSelectedIndex()+1;
		jLabel6.setIcon(new 
				ImageIcon(getClass().getClassLoader()
									.getResource("img/icon/"+index+".png")));
	}
	
	private void close(ActionEvent evt) {
		this.dispose();//����
		loginJFrame.setVisible(true);//��¼������ʾ
	}
	
	//java_xxxxx
	private void regedit(ActionEvent evt) {
		String nickname=jTextField1.getText().trim();
		String password=new String(jPasswordField1.getPassword()).trim();
		String age=jTextField2.getText().trim();
		String email=jTextField3.getText().trim();
		String img=String.valueOf(jComboBox1.getSelectedIndex()+1);
		User u=new User();
		u.setNickname(nickname);
		u.setAge(Integer.parseInt(age));
		u.setEmail(email);
		u.setPassword(password);
		u.setImg(img);//1 2 3 4
		try {
			RegeditRS rs=sBiz.regedit(u);
			if(rs.isRs())
			{//ע��ɹ�����
				this.dispose();//����
				DialogUtil.showInfo(rs.getMsg());
				loginJFrame.setVisible(true);
			}else{//ע��ʧ�ܣ���
				DialogUtil.showAlarm(rs.getMsg());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}//ע�Ṧ��
	}

}
