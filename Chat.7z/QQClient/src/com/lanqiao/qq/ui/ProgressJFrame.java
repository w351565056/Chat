package com.lanqiao.qq.ui;
import javax.swing.JLabel;
import javax.swing.JProgressBar;

import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class ProgressJFrame extends javax.swing.JFrame {
	private JLabel jLabel1;
	private JProgressBar jProgressBar1;
	//=============================
	private long filesize;//�ļ���С����
	private long writesize;//д�˵��ļ���С
	

	public void setFilesize(long filesize) {
		this.filesize = filesize;
	}

	//100  5 + 5
	public void setWritesize(long size) {
		writesize=writesize+size;
		long value=100*writesize/filesize; 
		jProgressBar1.setValue((int) value);
		jProgressBar1.setString(value+"%");
	}
	
	public void setLable(String msg)
	{
		jLabel1.setText(msg);
	}

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				ProgressJFrame inst = new ProgressJFrame();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public ProgressJFrame() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			getContentPane().setLayout(null);
			this.setTitle("\u6587\u4ef6\u4f20\u9001");
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1);
				jLabel1.setBounds(36, 33, 342, 31);
			}
			{
				jProgressBar1 = new JProgressBar();
				getContentPane().add(jProgressBar1);
				jProgressBar1.setBounds(36, 84, 335, 28);
				jProgressBar1.setStringPainted(true);
			}
			pack();
			this.setSize(427, 173);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
