package com.lanqiao.qq.ui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.Socket;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import com.lanqiao.qq.biz.SysBiz;
import com.lanqiao.qq.util.DialogUtil;
import com.lanqiao.qq.entity.Find;
import com.lanqiao.qq.entity.User;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class FindJFrame extends javax.swing.JFrame {
	private JRadioButton jRadioButton1;
	private JTextField jTextField1;
	private JButton jButton1;
	private JButton jButton2;
	private JRadioButton jRadioButton2;
	//============================================
	private ButtonGroup bg;
    private 	SysBiz sBiz;
    private Socket s;
    private User u;
	
	public FindJFrame(Socket s,User u) {
		super();
		this.s=s;
		this.u=u;
		sBiz=new SysBiz(s);
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			{
				jRadioButton1 = new JRadioButton();
				getContentPane().add(jRadioButton1);
				jRadioButton1.setText("\u7cbe\u786e\u67e5\u627e");
				jRadioButton1.setBounds(19, 34, 79, 23);
				jRadioButton1.setBackground(new java.awt.Color(128,255,255));
			}
			{
				jTextField1 = new JTextField();
				getContentPane().add(jTextField1);
				jTextField1.setBounds(43, 72, 286, 24);
			}
			{
				jRadioButton2 = new JRadioButton();
				getContentPane().add(jRadioButton2);
				jRadioButton2.setText("\u67e5\u627e\u6240\u6709");
				jRadioButton2.setBounds(19, 137, 79, 27);
				jRadioButton2.setBackground(new java.awt.Color(128,255,255));
				jRadioButton2.setSelected(true);
			}
			{
				jButton1 = new JButton();
				getContentPane().add(jButton1);
				jButton1.setText("\u67e5\u627e");
				jButton1.setBounds(43, 191, 69, 24);
				jButton1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						find(evt);
					}
				});
			}
			{
				jButton2 = new JButton();
				getContentPane().add(jButton2);
				jButton2.setText("\u5173\u95ed");
				jButton2.setBounds(221, 191, 75, 24);
				jButton2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						close(evt);
					}
				});
			}
			{
				bg=new ButtonGroup();
				bg.add(jRadioButton1);
				bg.add(jRadioButton2);
			}
			pack();
			this.setSize(394, 297);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void close(ActionEvent evt) {
		this.dispose();
	}
	
	private void find(ActionEvent evt) {
		//��ȷ����    ��������
		Find find=new Find();
		if(jRadioButton1.isSelected())
		{//��ȷ
			find.setType(Find.ONE);
			find.setFaccount(jTextField1.getText().trim());//�����˺�
		}else{//����
			find.setType(Find.ALL);
		}
		//�Ѳ��ҵ���Ϣ���͸�������
		try {
			sBiz.find(find);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
