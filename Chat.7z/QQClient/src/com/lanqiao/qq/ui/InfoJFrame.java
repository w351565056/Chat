package com.lanqiao.qq.ui;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import com.lanqiao.qq.entity.User;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class InfoJFrame extends javax.swing.JFrame {
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JButton jButton1;
	private JLabel jLabel10;
	private JLabel jLabel9;
	private JLabel jLabel8;
	private JLabel jLabel7;
	private JLabel jLabel6;
	//=================================
	private User u;
	
	public InfoJFrame(User u) {
		super();
		this.u=u;
		initGUI();
		initInfo();
	}
	
	/**
	 * ��ʼ�������û���ʾ��Ϣ
	 */
	private void initInfo()
	{
		jLabel6.setText(u.getAccount());
		jLabel7.setText(u.getNickname());
		jLabel8.setText(String.valueOf(u.getAge()));
		jLabel9.setText(u.getEmail());
		jLabel10.setIcon(new ImageIcon(getClass()
				.getClassLoader().getResource("img/icon/"+u.getImg()+".png")));
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1);
				jLabel1.setText("\u8d26\u53f7\uff1a");
				jLabel1.setBounds(12, 29, 58, 22);
			}
			{
				jLabel2 = new JLabel();
				getContentPane().add(jLabel2);
				jLabel2.setText("\u6635\u79f0\uff1a");
				jLabel2.setBounds(12, 71, 58, 22);
			}
			{
				jLabel3 = new JLabel();
				getContentPane().add(jLabel3);
				jLabel3.setText("\u5e74\u9f84\uff1a");
				jLabel3.setBounds(12, 113, 58, 22);
			}
			{
				jLabel4 = new JLabel();
				getContentPane().add(jLabel4);
				jLabel4.setText("\u90ae\u7bb1\uff1a");
				jLabel4.setBounds(12, 160, 58, 22);
			}
			{
				jLabel5 = new JLabel();
				getContentPane().add(jLabel5);
				jLabel5.setText("\u5934\u50cf\uff1a");
				jLabel5.setBounds(242, 34, 58, 22);
			}
			{
				jLabel6 = new JLabel();
				getContentPane().add(jLabel6);
				jLabel6.setBounds(61, 32, 166, 19);
			}
			{
				jLabel7 = new JLabel();
				getContentPane().add(jLabel7);
				jLabel7.setBounds(56, 78, 166, 19);
			}
			{
				jLabel8 = new JLabel();
				getContentPane().add(jLabel8);
				jLabel8.setBounds(58, 120, 166, 19);
			}
			{
				jLabel9 = new JLabel();
				getContentPane().add(jLabel9);
				jLabel9.setBounds(57, 163, 166, 19);
			}
			{
				jLabel10 = new JLabel();
				getContentPane().add(jLabel10);
				jLabel10.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/icon/1.png")));
				jLabel10.setBounds(279, 62, 50, 50);
			}
			{
				jButton1 = new JButton();
				getContentPane().add(jButton1);
				jButton1.setText("\u5173\u95ed");
				jButton1.setBounds(259, 160, 70, 24);
				jButton1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						close(evt);
					}
				});
			}
			pack();
			this.setSize(383, 264);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void close(ActionEvent evt) {
		this.dispose();
	}

}
