package com.lanqiao.qq.ui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.Socket;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.lanqiao.qq.biz.UserBiz;
import com.lanqiao.qq.util.DialogUtil;
import com.lanqiao.qq.entity.AddFriendsMsg;
import com.lanqiao.qq.entity.User;

/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class FindRSJFrame extends javax.swing.JFrame {
	private JScrollPane jScrollPane1;
	private JButton jButton1;
	private JButton jButton2;
	private JTable jTable1;
	//==================================
	private List<User> ulist;
	private User u;//��ǰ��¼���û�
	private UserBiz uBiz;
//	private Socket s;
	
	public FindRSJFrame(List<User> ulist,User u,Socket s) {
		super();
		this.ulist=ulist;
		this.u=u;
//		this.s=s;
		this.uBiz=new UserBiz(s);
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			getContentPane().setLayout(null);
			{
				jScrollPane1 = new JScrollPane();
				getContentPane().add(jScrollPane1);
				jScrollPane1.setBounds(29, 23, 449, 213);
				{
					TableModel jTable1Model = 
						new DefaultTableModel(
								getForTable(),
								new String[] { "�˺�", "�ǳ�" });
					jTable1 = new JTable();
					jScrollPane1.setViewportView(jTable1);
					jTable1.setModel(jTable1Model);
					jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				}
			}
			{
				jButton1 = new JButton();
				getContentPane().add(jButton1);
				jButton1.setText("\u67e5\u770b\u4fe1\u606f");
				jButton1.setBounds(61, 253, 120, 24);
				jButton1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						showInfo(evt);
					}
				});
			}
			{
				jButton2 = new JButton();
				getContentPane().add(jButton2);
				jButton2.setText("\u6dfb\u52a0\u597d\u53cb");
				jButton2.setBounds(298, 253, 111, 24);
				jButton2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						addFriends(evt);
					}
				});
			}
			pack();
			this.setSize(530, 353);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * ��list�е�User��Ϣת��ΪString[][]��ʽ
	 * @return
	 */
	private String[][] getForTable()
	{
		String strs[][]=new String[ulist.size()][2];
		for(int x=0;x<ulist.size();x++)
		{
			strs[x][0]=ulist.get(x).getAccount();
			strs[x][1]=ulist.get(x).getNickname();
		}
		return strs;
	}
	
	private void showInfo(ActionEvent evt) {
		int index=jTable1.getSelectedRow();
		if(index!=-1)
		{//ѡ��
			InfoJFrame info=new InfoJFrame(ulist.get(index));
			info.setLocationRelativeTo(null);
			info.setVisible(true);
		}else{//û��ѡ��
			DialogUtil.showAlarm("��ѡ��һ���û�������");
		}
	}
	
	private void addFriends(ActionEvent evt) {
		int index=jTable1.getSelectedRow();
		if(index!=-1)
		{//ѡ��
			User f=ulist.get(index);//Ҫ���ӵĺ���
			AddFriendsMsg msg=new AddFriendsMsg();
			msg.setTo(f);
			msg.setFrom(u);
			try {
				uBiz.addFriends(msg);//�������Ӻ������󣡣�
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{//û��ѡ��
			DialogUtil.showAlarm("��ѡ��һ���û�������");
		}
	}

}
