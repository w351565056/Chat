package com.lanqiao.qq.ui;
import java.awt.JobAttributes.DialogType;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.lanqiao.qq.biz.SysBiz;
import com.lanqiao.qq.util.DialogUtil;
import com.lanqiao.qq.util.PropertiesUtil;
import com.lanqiao.qq.entity.User;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class LoginJFrame extends javax.swing.JFrame {
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JButton jButton1;
	private JPasswordField jPasswordField1;
	private JButton jButton2;
	private JLabel jLabel6;
	private JTextField jTextField1;
   //=====================================
	private Socket s;//���ӷ�������Socket
	private SysBiz sBiz;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				LoginJFrame inst = new LoginJFrame();
//				inst.setLocationRelativeTo(null);
//				inst.setVisible(true);
			}
		});
	}
	
	public LoginJFrame() {
		super();
		initGUI();
		this.setLocationRelativeTo(null);//���ô��ھ���
		this.setVisible(true);//���ô�����ʾ
		try {
			s=new Socket(PropertiesUtil.readPro("ip"),
							Integer.parseInt(PropertiesUtil.readPro("port")));
			sBiz=new SysBiz(s);
		} catch (IOException e) {
			//���Ի�����ʾ��
			DialogUtil.showAlarm("���ӷ�����ʧ�ܣ�����");
			e.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1);
				jLabel1.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/login/qq.PNG")));
				jLabel1.setBounds(0, 6, 322, 45);
			}
			{
				jLabel2 = new JLabel();
				getContentPane().add(jLabel2);
				jLabel2.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/login/id.png")));
				jLabel2.setBounds(12, 75, 40, 21);
			}
			{
				jLabel3 = new JLabel();
				getContentPane().add(jLabel3);
				jLabel3.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/login/pw.png")));
				jLabel3.setBounds(12, 129, 40, 22);
			}
			{
				jLabel4 = new JLabel();
				getContentPane().add(jLabel4);
				jLabel4.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/login/2-2.png")));
				jLabel4.setBounds(41, 171, 221, 17);
			}
			{
				jTextField1 = new JTextField();
				getContentPane().add(jTextField1);
				jTextField1.setBounds(64, 75, 175, 24);
			}
			{
				jLabel5 = new JLabel();
				getContentPane().add(jLabel5);
				jLabel5.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/login/reg.png")));
				jLabel5.setBounds(251, 78, 65, 21);
				jLabel5.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						regedit(evt);
					}
				});
			}
			{
				jLabel6 = new JLabel();
				getContentPane().add(jLabel6);
				jLabel6.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/login/qh.png")));
				jLabel6.setBounds(251, 131, 65, 21);
			}
			{
				jButton1 = new JButton();
				getContentPane().add(jButton1);
				jButton1.setText("\u767b\u5f55");
				jButton1.setBounds(41, 200, 74, 24);
				jButton1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						login(evt);
					}
				});
			}
			{
				jButton2 = new JButton();
				getContentPane().add(jButton2);
				jButton2.setText("\u8bbe\u7f6e");
				jButton2.setBounds(200, 200, 68, 24);
			}
			{
				jPasswordField1 = new JPasswordField();
				getContentPane().add(jPasswordField1);
				jPasswordField1.setBounds(64, 125, 175, 24);
			}
			pack();
			this.setSize(343, 280);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void login(ActionEvent evt) {
		String name=jTextField1.getText().trim();
		String password=new String(jPasswordField1.getPassword()).trim();
		//ʹ�ö������л�
		//1.�����һ��(����+����)
		//2.ʵ�����л��ӿ�
		User u=new User();
		u.setAccount(name);
		u.setPassword(password);
		try {
			User u1=sBiz.login(u);
			if(u1==null)
			{//ʧ��
				DialogUtil.showAlarm("�û������������");
			}else{//�ɹ�
				System.out.println("����������"+u1.getFriends().size());
//				DialogUtil.showAlarm("��¼�ɹ���");
				this.dispose();
				MainJFrame mj=new MainJFrame(u1,s);
				mj.setLocationRelativeTo(null);
				mj.setVisible(true);
			}
		} catch (IOException e) {
			e.printStackTrace();
			DialogUtil.showAlarm("�������쳣��");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			DialogUtil.showAlarm("�������쳣��");
		}
		
	}
	
	private void regedit(MouseEvent evt) {
		this.setVisible(false);//��¼������ʧ
		RegeditJFrame  rf=new RegeditJFrame(this,s);
		rf.setLocationRelativeTo(null);
		rf.setVisible(true);
		
	}

}
