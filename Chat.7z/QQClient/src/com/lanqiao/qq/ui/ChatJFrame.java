package com.lanqiao.qq.ui;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import com.lanqiao.qq.biz.UserBiz;
import com.lanqiao.qq.util.DialogUtil;
import com.lanqiao.qq.entity.SendFileMsg;
import com.lanqiao.qq.entity.SendMsg;
import com.lanqiao.qq.entity.User;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class ChatJFrame extends javax.swing.JFrame {
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JTextArea jTextArea2;
	private JTextArea jTextArea1;
	private JLabel jLabel6;
	//==================================
	private User f;//����
	private JScrollPane jScrollPane2;
	private JScrollPane jScrollPane1;
	private User u;
	private UserBiz uBiz;

	public ChatJFrame(User f,User u,Socket s) {
		super();
		this.f=f;
		this.u=u;
		uBiz=new UserBiz(s);
		initGUI();
		setTitle(f.getNickname());
	}
	
	public void appendMsg(SendMsg msg)
	{
		jTextArea2.append(msg.toString());
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setBackground(new java.awt.Color(128,255,255));
			getContentPane().setLayout(null);
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1);
				jLabel1.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/chat/female.png")));
				jLabel1.setBounds(286, 6, 130, 199);
			}
			{
				jLabel2 = new JLabel();
				getContentPane().add(jLabel2);
				jLabel2.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/chat/male.png")));
				jLabel2.setBounds(282, 249, 130, 199);
			}
			{
				jLabel3 = new JLabel();
				getContentPane().add(jLabel3);
				jLabel3.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/chat/1.png")));
				jLabel3.setBounds(7, 217, 390, 26);
			}
			{
				jLabel4 = new JLabel();
				getContentPane().add(jLabel4);
				jLabel4.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/chat/folder.png")));
				jLabel4.setBounds(12, 439, 25, 25);
				jLabel4.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						sendFile(evt);
					}
				});
			}
			{
				jLabel5 = new JLabel();
				getContentPane().add(jLabel5);
				jLabel5.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/chat/send1.png")));
				jLabel5.setBounds(98, 441, 69, 21);
				jLabel5.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						sendMsg(evt);
					}
				});
			}
			{
				jLabel6 = new JLabel();
				getContentPane().add(jLabel6);
				jLabel6.setIcon(new ImageIcon(getClass().getClassLoader().getResource("img/chat/close1.png")));
				jLabel6.setBounds(188, 441, 69, 21);
				jLabel6.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						close(evt);
					}
				});
			}
			{
				jScrollPane1 = new JScrollPane();
				getContentPane().add(jScrollPane1);
				jScrollPane1.setBounds(19, 12, 255, 193);
				{
					jTextArea2 = new JTextArea();
					jScrollPane1.setViewportView(jTextArea2);
					jTextArea2.setEditable(false);
				}
			}
			{
				jScrollPane2 = new JScrollPane();
				getContentPane().add(jScrollPane2);
				jScrollPane2.setBounds(19, 261, 255, 174);
				{
					jTextArea1 = new JTextArea();
					jScrollPane2.setViewportView(jTextArea1);
					jTextArea1.setBounds(266, 159, 167, 135);
				}
			}
			pack();
			this.setSize(455, 512);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void close(MouseEvent evt) {
		this.setVisible(false);		
	}
	
	private void sendMsg(MouseEvent evt) {
		SendMsg msg=new SendMsg();
		msg.setFrom(u);
		msg.setTo(f);
		msg.setMsg(jTextArea1.getText());
		msg.setTime(new Date());
		try {
			uBiz.sendMsg(msg);
			jTextArea2.append(msg.toString());
			jTextArea1.setText("");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void sendFile(MouseEvent evt) {
		File file=DialogUtil.openFile();
		SendFileMsg msg=new SendFileMsg();
		msg.setFilename(file.getName());
		msg.setFilesize(file.length());
		msg.setFrom(u);
		msg.setTo(f);
		msg.setFilepath(file.getPath());
		try {
			uBiz.sendFileMsg(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
