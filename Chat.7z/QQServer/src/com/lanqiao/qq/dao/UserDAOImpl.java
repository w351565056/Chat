package com.lanqiao.qq.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lanqiao.qq.entity.User;
import com.lanqiao.qq.util.DBUtil;

public class UserDAOImpl implements UserDAO {

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	List<User> ulist;
	
	private void closeAll()
	{
		try {
			if(rs!=null)
			{
				rs.close();
			}
			if(pst!=null)
			{
				pst.close();
			}
			if(con!=null)
			{
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	@Override
	public User  isLogin(String account, String password) {
		sql="select * from uuser where account = ? and password = ?";
		try {
			con=DBUtil.getConn();
			pst=con.prepareStatement(sql);
			pst.setString(1, account);
			pst.setString(2, password);
			rs=pst.executeQuery();
			if(rs.next())
			{
				User u=new User();
				u.setAccount(rs.getString("account"));
				u.setAge(rs.getInt("age"));
				u.setEmail(rs.getString("email"));
				u.setImg(rs.getString("img"));
				u.setNickname(rs.getString("nickname"));
				u.setPassword(rs.getString("password"));
				return u;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeAll();
		}
		return null;
	}

	@Override
	public boolean addUser(User u) {
		sql="insert into uuser values (?,?,?,?,?,?)";
		try {
			con=DBUtil.getConn();
			pst=con.prepareStatement(sql);
			pst.setString(1, u.getAccount());
			pst.setString(2, u.getPassword());
			pst.setString(3, u.getNickname());
			pst.setInt(4, u.getAge());
			pst.setString(5, u.getEmail());
			pst.setString(6, u.getImg());
			pst.execute();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeAll();
		}
		return false;
	}


	@Override
	public int getNextAccount() {
		//1.select  +1  ->  2.update ����
		sql="select * from account";
		int id=-1;
		try {
			con=DBUtil.getConn();
			con.setAutoCommit(false);//���ò�Ҫ�����ύ
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();
			if(rs.next())
			{
				id=rs.getInt("id")+1;//10+1=11
				//�������ݿ�
				sql="update account set id = ?";
				pst=con.prepareStatement(sql);
				pst.setInt(1, id);
				pst.executeUpdate();//ִ�и��²�������
			}
			con.commit();//�ֶ��ύ�޸�
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally{
			try {
				con.setAutoCommit(true);//����Ϊ�Զ��ύ
			} catch (SQLException e) {
				e.printStackTrace();
			}
			closeAll();
		}
		return id;
	}


	@Override
	public List<User> queryFriends(String account) {
		List<User> ulist=new ArrayList<User>();
		sql="select * from uuser " +
				" where account in " +
				" (select fid from friends where uuid = ?)";
		try {
			con=DBUtil.getConn();
			pst=con.prepareStatement(sql);
			pst.setString(1, account);
			rs=pst.executeQuery();
			while(rs.next())
			{
				User u=new User();
				u.setAccount(rs.getString("account"));
				u.setAge(rs.getInt("age"));
				u.setEmail(rs.getString("email"));
				u.setImg(rs.getString("img"));
				u.setNickname(rs.getString("nickname"));
				u.setPassword(rs.getString("password"));
				ulist.add(u);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeAll();
		}
		return ulist;
	}


	@Override
	public List<User> queryAll() {
		List<User> ulist=new ArrayList<User>();
		sql="select * from uuser";
		try {
			con=DBUtil.getConn();
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();
			while(rs.next())
			{
				User u=new User();
				u.setAccount(rs.getString("account"));
				u.setAge(rs.getInt("age"));
				u.setEmail(rs.getString("email"));
				u.setImg(rs.getString("img"));
				u.setNickname(rs.getString("nickname"));
				u.setPassword(rs.getString("password"));
				ulist.add(u);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeAll();
		}
		return ulist;
	}


	@Override
	public User queryByAccount(String account) {
		sql="select * from uuser " +
				" where account = ? "; 
		try {
			con=DBUtil.getConn();
			pst=con.prepareStatement(sql);
			pst.setString(1, account);
			rs=pst.executeQuery();
			if(rs.next())
			{
				User u=new User();
				u.setAccount(rs.getString("account"));
				u.setAge(rs.getInt("age"));
				u.setEmail(rs.getString("email"));
				u.setImg(rs.getString("img"));
				u.setNickname(rs.getString("nickname"));
				u.setPassword(rs.getString("password"));
				return u;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeAll();
		}
		return null;
	}


	@Override
	public void addFriends(User u, User f) {
		sql="insert into friends values (?,?)";
		try {
			con=DBUtil.getConn();
			con.setAutoCommit(false);//���ò�Ҫ�����ύ
			pst=con.prepareStatement(sql);
			pst.setString(1, u.getAccount());
			pst.setString(2, f.getAccount());
			pst.executeUpdate();
			pst.clearParameters();
			pst.setString(1, f.getAccount());
			pst.setString(2, u.getAccount());
			pst.executeUpdate();
			con.commit();//�ֶ��ύ�޸�
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally{
			try {
				con.setAutoCommit(true);//����Ϊ�Զ��ύ
			} catch (SQLException e) {
				e.printStackTrace();
			}
			closeAll();
		}
	}

}
