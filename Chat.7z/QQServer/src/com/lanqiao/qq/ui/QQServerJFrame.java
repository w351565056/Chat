package com.lanqiao.qq.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lanqiao.qq.biz.ServerBiz;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class QQServerJFrame extends JFrame {

	private JPanel contentPane;
	private JButton startupButton;
	private JButton stopButton;

	private ServerBiz sbiz;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {

				try {
					QQServerJFrame frame = new QQServerJFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public QQServerJFrame() {
		sbiz = new ServerBiz();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 470, 246);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		startupButton = new JButton("启动服务");
		startupButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				startup(arg0);
			}
		});
		startupButton.setBounds(70, 78, 99, 43);
		contentPane.add(startupButton);

		stopButton = new JButton("停止服务");
		stopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stop(e);
			}
		});
		stopButton.setEnabled(false);
		stopButton.setBounds(301, 78, 93, 43);
		contentPane.add(stopButton);
	}

	// 启动服务
	private void startup(ActionEvent arg0) {
		new Thread() {
			public void run() {
				startupButton.setEnabled(false);
				stopButton.setEnabled(true);
				try {
					sbiz.startService();
				} catch (IOException e) {
					System.out.println("服务器启动失败");
					e.printStackTrace();
				}
			}
		}.start();

	}

	// 停止服务
	private void stop(ActionEvent e) {
		new Thread() {
			public void run() {
				startupButton.setEnabled(true);
				stopButton.setEnabled(false);
				try {
					sbiz.stopService();
				} catch (IOException e1) {
					System.out.println("服务器停止失败");
					e1.printStackTrace();
				}
			}
		}.start();

	}
}
