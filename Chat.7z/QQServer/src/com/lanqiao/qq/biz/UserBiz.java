package com.lanqiao.qq.biz;

import java.util.List;

import com.lanqiao.qq.dao.UserDAO;
import com.lanqiao.qq.dao.UserDAOImpl;
import com.lanqiao.qq.entity.AddRSMsg;
import com.lanqiao.qq.entity.RegeditRS;
import com.lanqiao.qq.entity.User;



public class UserBiz {
	
	private UserDAO udao;
	
	public UserBiz()
	{
		udao=new UserDAOImpl();
	}
	
	public  User isLogin(User u)
	{
		u=udao.isLogin(u.getAccount(), u.getPassword());
	    if(u!=null)
	    {
	    	//��������ȥ�ˣ���
			u.setFriends(udao.queryFriends(u.getAccount()));
	    }
		return u;
	}
	
	public RegeditRS regedit(User u)
	{
		RegeditRS rs=new RegeditRS();
		int i=udao.getNextAccount();//�����һ���˺���--->java_xxxx
		String account=String.format("%05d%n", i).trim();
		u.setAccount(account);//�����û�ע���˺ţ���
		boolean b=udao.addUser(u);
		if(b)
		{
			rs.setMsg("���ĵ�¼�˺�Ϊ��"+account);
			rs.setRs(true);
		}else{
			rs.setMsg("ע��ʧ�ܣ���");
			rs.setRs(false);
		}
		return rs;
	}
	
	public User queryByAccount(String account)
	{
		return udao.queryByAccount(account);
	}
	
	public List<User> queryAll()
	{
		return udao.queryAll();
	}
	
	public void addFriends(AddRSMsg msg)
	{
		udao.addFriends(msg.getForm(), msg.getTo());
	}
	
	

}
